# delivery-portal
A portal for customers and shopkeepers to manage deliveries.
